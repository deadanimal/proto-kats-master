import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-management-roles',
  templateUrl: './management-roles.component.html',
  styleUrls: ['./management-roles.component.scss']
})
export class ManagementRolesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
